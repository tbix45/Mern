import './App.css';
import Personcard from './components/Personcard';

function App() {
  return (
    <div className="App">
      <Personcard
        firstName={"Jane"}
        lastName={"Doe"}
        age={40}
        hairColor={"Brown"}
        profession={"Coder"}>
        <p>
          No one knows her real name.
        </p>
      </Personcard>
      <Personcard
        firstName={"John"}
        lastName={"Smith"}
        age={88}
        hairColor={"Black"}
        profession={"Boater"}>
        <p>
          His brother is John Wick.
        </p>
      </Personcard>
      <Personcard
        firstName={"Millard"}
        lastName={"Fillmore"}
        age={55}
        hairColor={"Brown"}
        profession={"Lawyer"}>
      </Personcard>
      <Personcard
        firstName={"Maria"}
        lastName={"Smith"}
        age={60}
        hairColor={"Red"}
        profession={"Rocker"}>
      </Personcard>
    </div>
  );
}

export default App;
